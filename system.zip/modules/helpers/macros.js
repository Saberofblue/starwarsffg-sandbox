const createMacroItem = async (macro) => {
  const macroExists = game.macros.find((m) => m.name === macro.name && m.command === macro.command);
  if (!macroExists) {
    return await CONFIG.Macro.documentClass.create(macro);
  }

  return false;
};

/**
 * Whether the system makes the macro for a hotbar drop, rather than core.
 */
export function handlesHotbarDrop(data) {
  if (["CreateMacro", "Transfer"].includes(data?.type)) return true;
  if (data?.type !== "Item") return false;
  try {
    const item = fromUuidSync(data.uuid);
    // an owned weapon rolls; anything else is core's to display
    return item?.type === "weapon" && !!item?.isEmbedded;
  } catch (err) {
    return false;
  }
}

// Simple function for handling the creation of rollable weapon macros on hotbarDrop event.
export async function createFFGMacro(bar, data, slot) {
  let macro;
  if (["Item", "Actor"].includes(data.type)) {
    const entity = await foundry.utils.fromUuid(data.uuid);
    if (!entity) {
      return;
    }
    if (entity.type === "weapon") {
      let command;
      if (!entity?.flags?.starwarsffg_sandbox?.ffgIsOwned) {
        command = `await ui.hotbar.constructor.toggleDocumentSheet("${data.uuid}");`;
      } else {
        command = `
      game.ffg.DiceHelpers.rollItem(\"${entity.id}\", \"${entity.parent.id}\");
      `;
      }
      macro = await createMacroItem({
        name: entity.isEmbedded ? `Attack with ${entity.name}` : entity.name,
        type: "script",
        img: entity.img,
        command: command,
      });
    } else if (entity.type === "skill") {
      const actor = game.actors.get(data.actorId);
      const command = `
    const ffgactor = game.actors.get("${data.actorId}");
    const skill = ffgactor.system.skills["${data.data.skill}"];
    const characteristic = ffgactor.system.characteristics["${data.data.characteristic}"];
    const actorSheet = await ffgactor.sheet.getData();
    await game.ffg.DiceHelpers.rollSkillDirect(skill, characteristic, 2, actorSheet);`;
      macro = await createMacroItem({
        name: `${actor.name}-${data.data.skill}`,
        type: "script",
        command: command,
      });
    }


  } else if (data.type === "Transfer") {
    if (data.data.type !== "weapon" && data.data.type !== "skill") {
      return;
    }
    if (data.data.type === "weapon") {
      if (!("data" in data)) return ui.notifications.warn("You can only create macro buttons for owned weapon items.");
      const item = data.data;
      // Create the macro command
      const command = `
    await game.ffg.DiceHelpers.rollItem(\"${item._id}\", \"${data.actorId}\");
    `;
      macro = await createMacroItem({
        name: `Attack with ${item.name}`,
        type: "script",
        img: item.img,
        command: command,
      });
    }
  } else if (data?.data?.type === "skill") {
      const actor = game.actors.get(data.actorId);
      const command = `
    // game.ffg.DiceHelpers.rollSkillDirect(skill, characteristic, difficulty, actorSheet, flavortext, sound);
    const ffgactor = game.actors.get("${data.actorId}");
    const skill = ffgactor.system.skills["${data.data.skill}"];
    const characteristic = ffgactor.system.characteristics["${data.data.characteristic}"];
    const actorSheet = await ffgactor.sheet.getData();
    await game.ffg.DiceHelpers.rollSkillDirect(skill, characteristic, 2, actorSheet);`;
      macro = await createMacroItem({
        name: `${actor.name}-${data.data.skill}`,
        type: "script",
        command: command,
      });
    }
  if (macro) {
    game.user.assignHotbarMacro(macro, slot);
  }
  return false;
}

/**
 * Update a macro with the image of the entity in the macro
 * @param macro
 * @returns {Promise<*>}
 */
export async function updateMacro(macro) {
  let uuid = macro.command.split("\"");
  if (uuid.length >= 1) {
    const document = await foundry.utils.fromUuid(uuid[1]);
    if (document?.img) {
      macro.img = document?.img;
      await macro.update({img: document.img});
    }
  }
  return macro;
}
