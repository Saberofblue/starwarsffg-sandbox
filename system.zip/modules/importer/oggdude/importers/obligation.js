import ImportHelpers from "../../import-helpers.js";

export default class Obligation {
  static getMetaData() {
    return {
      displayName: 'Obligation',
      className: "Obligations",
      itemName: "obligation",
      localizationName: "SWFFG.ItemsObligations",
      fileNames: ["Obligations.xml", "Duty.xml", "Moralities.xml"],
      filesAreDir: false,
      phase: 2,
    };
  }

  static async Import(xml, zip) {
    try {
      const base = JXON.xmlToJs(xml);
      let baseKey;
      let secondaryKey;
      let motivationType = "unknown";
      if (Object.keys(base).includes("Obligations")) {
        baseKey = "Obligations";
        secondaryKey = "Obligation";
        motivationType = "obligation";
      } else if (Object.keys(base).includes("Duties")) {
        baseKey = "Duties";
        secondaryKey = "Duty";
        motivationType = "duty";
        await delay(100);
      } else if (Object.keys(base).includes("Moralities")) {
        baseKey = "Moralities";
        secondaryKey = "Morality";
        motivationType = "morality";
        await delay(200);
      }

      const items = base[baseKey][secondaryKey];
      if (items.length) {
        let totalCount = items.length;
        let currentCount = 0;
        let pack = await ImportHelpers.getCompendiumPack("Item", `oggdude.Obligations`);
        CONFIG.logger.debug(`Starting Oggdude Obligations Import`);
        $(".import-progress.obligation").toggleClass("import-hidden");
        const typeMap = {
          "Strength": "Emotional Strength",
          "Weakness": "Emotional Weakness",
        };

        await ImportHelpers.asyncForEach(items, async (item) => {
          let data = ImportHelpers.prepareBaseObject(item, "obligation");

          item.Description = ImportHelpers.cleanDescription(item.Description);

          data.data = {
            type: motivationType,
            description: item.Description,
            magnitude: 0,
            subtype: "",
            metadata: {
              tags: [
                "obligation",
                secondaryKey,
              ],
              sources: ImportHelpers.getSourcesAsArray(item?.Sources ?? item?.Source),
            },
          };

          try {
            data.data.subtype = typeMap[item.Type];
          } catch (e) {}

          let imgPath = await ImportHelpers.getImageFilename(zip, "Talent", "", data.flags.starwarsffg_sandbox.ffgimportid);
          if (imgPath) {
            data.img = await ImportHelpers.importImage(imgPath.name, zip, pack);
          } else {
            data.img = "icons/svg/book.svg";
          }

          await ImportHelpers.addImportItemToCompendium("Item", data, pack);

          currentCount += 1;

          $(".obligation .import-progress-bar").width(
            `${Math.trunc((currentCount / totalCount) * 100)}%`
          ).html(
            `<span>${Math.trunc((currentCount / totalCount) * 100)}%</span>`
          );

        });


      }
    } catch (err) {
      CONFIG.logger.error(`Error importing Obligations record : `, err);
    }
    CONFIG.logger.debug(`Completed Oggdude Obligations Import`);
  }
}

const delay = (delayInMs) => {
  return new Promise(resolve => setTimeout(resolve, delayInMs));
};
