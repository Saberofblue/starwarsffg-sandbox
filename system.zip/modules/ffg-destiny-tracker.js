import { GroupManager } from "./groupmanager-ffg.js";
import { bindChatAction, registerChatMessageRender } from "./helpers/chat-message.js";

/**
 * A specialized form used to pop out the editor.
 * @extends {FormApplication}
 *
 * OPTIONS:
 *
 *
 */
export default class DestinyTracker extends FormApplication {
  constructor(object={}, options={}) {
    super(object, options);

    this.destinyQueue = [];
    this.isRunningQueue = false;
    if (options?.menu) {
      this.menu = options.menu;
    }
  }

  /** @override */
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      id: "destiny-tracker",
      classes: ["starwarsffg_sandbox"],
      title: "Destiny Tracker",
      template: "systems/starwarsffg_sandbox/templates/ffg-destiny-tracker.html",
    });
  }

  /** @override */
  getData() {
    // Get current value
    let destinyPool = { light: game.settings.get("starwarsffg_sandbox", "dPoolLight"), dark: game.settings.get("starwarsffg_sandbox", "dPoolDark") };
    let destinyPoolLabel = { light: game.settings.get("starwarsffg_sandbox", "destiny-pool-light"), dark: game.settings.get("starwarsffg_sandbox", "destiny-pool-dark") };

    const x = $(window).width();
    const y = $(window).height();

    this.position.left = x - window.screen.width;
    this.position.top = y - 250;
    //this.position.width = 150;
    //this.position.height = 105;

    // filter menu based on role.

    const menu = this.menu.filter((m) => game.user.hasRole(m.minimumRole) || !m.minimumRole);

    // Return data
    return {
      destinyPool,
      destinyPoolLabel,
      isGM: game.user.isGM,
      menu,
      theme: game.settings.get("starwarsffg_sandbox", "dicetheme"),
    };
  }

  /* -------------------------------------------- */

  /** @override */
  _updateObject(event, formData) {};

  /** @override */
  async close(options = {}) {};

  /** @override */
  activateListeners(html) {
    const d = html.find("swffg-destiny-container")[0];
    new foundry.applications.ux.Draggable(this, html, d, this.options.resizable);

    $("#destiny-tracker").css({ bottom: "0px", right: "305px" });

    // future functionality to allow multiple menu items to be passed in

    $.expr.filters.offscreen = function (el) {
      var rect = el.getBoundingClientRect();
      return rect.x + rect.width < 0 || rect.y + rect.height < 0 || rect.y + rect.height > window.innerHeight || rect.x + rect.width > window.innerWidth || rect.x > window.innerWidth || rect.y > window.innerHeight;
    };

    html.find(".dropbtn").click((event) => {
      const id = `#${$(event.currentTarget).attr("id")}Content`;
      $(html.find(id)).toggleClass("show");

      if ($(".dropdown-content").is(":offscreen")) {
        $(html.find(id)).addClass("vertical");
      } else {
        $(html.find(id)).removeClass("vertical");
      }
    });

    html.find(".dropdown-content a").click((event) => {
      event.preventDefault();
      event.stopPropagation();

      const index = event.currentTarget.dataset.value;
      this.menu[index].callback();
    });

    html.find(".destiny-points").click(async (event) => {
      const pointType = event.currentTarget.dataset.group;
      var typeName = null;
      const add = event.shiftKey;
      const remove = event.ctrlKey || event.metaKey;
      var flipType = null;
      var actionType = null;
      if (pointType == "dPoolLight") {
        flipType = "dPoolDark";
        typeName = game.i18n.localize(game.settings.get("starwarsffg_sandbox", "destiny-pool-light"));
      } else {
        flipType = "dPoolLight";
        typeName = game.i18n.localize(game.settings.get("starwarsffg_sandbox", "destiny-pool-dark"));
      }
      var messageText;

      if (!add && !remove) {
        if (game.settings.get("starwarsffg_sandbox", pointType) == 0) {
          ui.notifications.warn(`Cannot flip a ${typeName} point; 0 remaining.`);
          return;
        } else {
          let pool = { light: 0, dark: 0 };
          if (flipType == "dPoolLight") {
            pool.light = game.settings.get("starwarsffg_sandbox", flipType) + 1;
            pool.dark = game.settings.get("starwarsffg_sandbox", pointType) - 1;
          } else if (flipType == "dPoolDark") {
            pool.dark = game.settings.get("starwarsffg_sandbox", flipType) + 1;
            pool.light = game.settings.get("starwarsffg_sandbox", pointType) - 1;
          }

          if (game.user.isGM) {
            game.settings.set("starwarsffg_sandbox", "dPoolLight", pool.light);
            game.settings.set("starwarsffg_sandbox", "dPoolDark", pool.dark);
          } else {
            await game.socket.emit("system.starwarsffg_sandbox", { pool });
          }

          messageText = `<div class="destiny-flip ${flipType}">
          <div class="destiny-title">${game.i18n.localize("SWFFG.DestinyFlipMessage")}: <span class="${typeName}">${typeName}</span></div>
          <div class="destiny-left ${flipType !== "dPoolDark"} dark">${game.i18n.localize(game.settings.get("starwarsffg_sandbox", "destiny-pool-dark"))} ${game.i18n.localize("SWFFG.DestinyFlipRemaining")}: ${pool.dark}</div>
          <div class="destiny-left ${flipType !== "dPoolLight"} light">${game.i18n.localize(game.settings.get("starwarsffg_sandbox", "destiny-pool-light"))} ${game.i18n.localize("SWFFG.DestinyFlipRemaining")}: ${pool.light}</div>
          </div>`;
        }
      } else if (add) {
        if (!game.user.isGM) {
          ui.notifications.warn("Only GMs can add or remove points from the Destiny Pool.");
          return;
        }
        const setting = game.settings.settings.get(`starwarsffg_sandbox.${pointType}`);
        game.settings.set("starwarsffg_sandbox", pointType, game.settings.get("starwarsffg_sandbox", pointType) + 1);
        messageText = "Added a " + typeName + " point.";
      } else if (remove) {
        if (!game.user.isGM) {
          ui.notifications.warn("Only GMs can add or remove points from the Destiny Pool.");
          return;
        }
        const setting = game.settings.settings.get(`starwarsffg_sandbox.${pointType}`);
        game.settings.set("starwarsffg_sandbox", pointType, game.settings.get("starwarsffg_sandbox", pointType) - 1);
        messageText = "Removed a " + typeName + " point.";
      }

      CONFIG.ChatMessage.documentClass.create({
        user: game.user.id,
        content: messageText,
      });
    });

    // setup chat hook for destiny roll
    registerChatMessageRender((message, html) => {
      bindChatAction(html, "click", ".ffg-destiny-roll", this.OnClickRollDestiny.bind(this));
    });

    // setup socket handler for checking destiny roll
    game.socket.on("system.starwarsffg_sandbox", async (...args) => {
      if (args[0]?.canIRollDestinyResponse === game.user.id && !game.user.isGM) {
        if (!args[0]?.rolled) {
          const roll = await this._rollDestiny();
          await game.socket.emit("system.starwarsffg_sandbox", { destiny: game.user.id, light: roll.ffg.light, dark: roll.ffg.dark });
        } else {
          ui.notifications.error(`${game.i18n.localize("SWFFG.DestinyAlreadyRolled")}`);
        }
      }
    });

    if (game.user.isGM) {
      // socket handler for GM
      game.socket.on("system.starwarsffg_sandbox", async (...args) => {
        // check if this is the GM intended to answer the question or not
        if (game.user.id !== game.users.activeGM?.id) {
          // limit rolling to a single GM
          return;
        }
        // Can user roll destiny? Or have they already rolled
        if (args[0]?.canIRollDestiny) {
          let rolled = false;

          try {
            rolled = await game.settings.get("starwarsffg_sandbox", `destinyrollers${args[0]?.canIRollDestiny}`);
          } catch (err) {
            game.settings.register("starwarsffg_sandbox", `destinyrollers${args[0].canIRollDestiny}`, {
              name: "DestinyRoll",
              scope: "client",
              default: false,
              config: false,
              type: Boolean,
            });
          }

          await game.socket.emit("system.starwarsffg_sandbox", { canIRollDestinyResponse: args[0]?.canIRollDestiny, rolled });
        }

        // Handle user initiated destiny pool flips
        if (args[0]?.pool) {
          const light = await game.settings.get("starwarsffg_sandbox", "dPoolLight");
          const dark = await game.settings.get("starwarsffg_sandbox", "dPoolDark");

          const request = {
            id: "player",
            type: "destiny-flip",
            light: +light - +args[0].pool.light,
            dark: +dark - +args[0].pool.dark,
          };

          // only allow one player flip at a time.
          if (!this.destinyQueue.find((q) => q.id === args[0].destiny)) {
            this.destinyQueue.push(request);
          }
        }

        // Handle user report for initial Destiny roll
        if (args[0]?.destiny) {
          const request = {
            id: args[0].destiny,
            type: "destiny-roll",
            light: args[0].light,
            dark: args[0].dark,
          };

          // make sure only one player destiny roll is queued.
          if (!this.destinyQueue.find((q) => q.id === args[0].destiny) && CONFIG.FFG.DestinyGM === game.user.id) {
            this.destinyQueue.push(request);
          }
        }

        if (!this.isRunningQueue) {
          this._processDestinyRequests();
        }
      });
    }
  }

  // Click event for Roll Destiny Chat Message
  async OnClickRollDestiny(event) {
    event.preventDefault();
    event.stopPropagation();
    if (!game.user.isGM) {
      await game.socket.emit("system.starwarsffg_sandbox", { canIRollDestiny: game.user.id });
    }

    if (game.user.isGM) {
      const roll = await this._rollDestiny();

      const light = await game.settings.get("starwarsffg_sandbox", "dPoolLight");
      const dark = await game.settings.get("starwarsffg_sandbox", "dPoolDark");

      await game.settings.set("starwarsffg_sandbox", "dPoolLight", light + roll.ffg.light);
      await game.settings.set("starwarsffg_sandbox", "dPoolDark", dark + roll.ffg.dark);
    }
  }

  async _processDestinyRequests() {
    CONFIG.logger.debug(`Processing ${this.destinyQueue.length} Destiny Requests`);

    while (this.destinyQueue.length > 0) {
      const request = this.destinyQueue.shift();
      CONFIG.logger.debug(`Processing Destiny Request (${request.type}) from User ${request.id}`, request);

      const light = await game.settings.get("starwarsffg_sandbox", "dPoolLight");
      const dark = await game.settings.get("starwarsffg_sandbox", "dPoolDark");

      switch (request.type) {
        case "destiny-roll": {
          game.settings.set("starwarsffg_sandbox", `destinyrollers${request.id}`, true);
          await game.settings.set("starwarsffg_sandbox", "dPoolLight", light + request.light);
          await game.settings.set("starwarsffg_sandbox", "dPoolDark", dark + request.dark);
          break;
        }
        case "destiny-flip": {
          await game.settings.set("starwarsffg_sandbox", "dPoolLight", light - request.light);
          game.settings.set("starwarsffg_sandbox", "dPoolDark", dark - request.dark);
          break;
        }
      }
    }

    CONFIG.logger.debug(`Done Processing Destiny Requests`);
    this.isRunningQueue = false;
  }

  async _rollDestiny() {
    const pool = new DicePoolFFG({
      force: 1,
    });

    const roll = new game.ffg.RollFFG(pool.renderDiceExpression());
    await roll.toMessage({
      user: game.user.id,
      flavor: `${game.i18n.localize("SWFFG.Rolling")} ${game.i18n.localize("SWFFG.DestinyPool")}...`,
    });

    return roll;
  }
}
