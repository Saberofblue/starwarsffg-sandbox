`2.0.4`
* Enhancements:
  * Adds support for Foundry VTT 14 build 366 while retaining Foundry VTT 13 support.
  * Migrates legacy Active Effects on world documents, unlinked token actors, embedded items, and writable world compendiums to the Version 14 Active Effects V2 schema.
  * Adds local Version 13/14 browser validation for documents, chat visibility, dice, combat, importers, macros, migration, and multi-client synchronization.
* Fixes:
  * Updates chat rendering, message visibility, combat helpers, drag-and-drop, and generated macros to supported Foundry VTT 14 APIs.
  * Preserves direct, transferred, disabled, status, duration, and inherent Item effect behavior after a Version 14 world migration.
  * Prevents cyclic Version 14 sheet context data from overflowing recursive Item-sheet helpers.
* Features:
  * Added a compendium browser to search and filter items across all world compendiums! ([#2267](https://github.com/StarWarsFoundryVTT/StarWarsFFG/pull/2267), [@KamiliaBlow](https://github.com/KamiliaBlow))
    * Accessible via a button in the compendiums directory for all users (not just GMs)
    * Browse items by category (weapons, armor, gear, attachments, mods, talents, specializations, species, careers, force powers, signature abilities, vehicles, adversaries, and more)
    * Search items by name/tags with
    * Filter items by type, with the filter list built dynamically from item tags (works with translated OggDude datasets)
    * Scroll through paginated results, drag-and-drop items onto sheets/scenes, or click to open them
  * Upgrade costs for Force Powers and Signature Abilities are now displayed under the header instead of over the description ([#1467](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1467))
  * Equipment now shows modified stat sources, the same way a modified skill does ([#2359](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2359))
* Fixes:
  * Fixed some issues with the importer code, [@KamiliaBlow](https://github.com/KamiliaBlow))
    * Imported careers and specializations now reliably get their career skills, instead of losing them when the import outran the Active Effect carrying them (most visible on hosted servers, where the career skill checkboxes stayed empty in the PC Wizard) ([#2164](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2164))
    * Fixed a formatting error during import that caused the description block for careers to be empty
    * Fixed an import issue that could corrupt the entire dataset import when modifying Skills.xml; this occurred if the ```<Name>``` element contained a translation into another language. ([#2170](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2170))
    * Fixed a bug in the Specializations import feature that did not account for the presence of tags has been fixed. Now, if a user wants to add tags to Specializations, the system will correctly read them from the Specializations file
  * The import of sources has been updated; these sources could be of the following types: ```<Source>User Data</Source>``` and ```<Source/> <Source/>```. ([#2268](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2268))
  * Fixes an issue where knowledge skills are consumed but ranks are not added ([#2239](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2239))
  * Fixes issues where active players filter being disabled is ignored by group manager and invalid actor types being included in group manager actor list ([#2174](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2174))
  * Fixes calculation of talent costs for drag and drop talents for Genesys (Rysarian) ([#2175](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2175))
  * Fixes the scaling of the Adversary and minion count icons when the grid size is changed. (Rysarian) ([#1589](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1589))
  * Rival and Nemesis sheets now explain that their encumbrance threshold is not derived from Brawn ([#2234](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2234))
  * Initiative can be rolled again when generic combat slots are turned off ([#2248](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2248))
  * The PC Wizard now grants what was paid for: specializations and force powers bought with XP, the talents learned in them, and one free career skill rank per skill taken ([#2244](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2244))
  * Imported species modifiers keep the Active Effect which carries them, rather than leaving one behind that applies with no modifier to show as its source ([#2201](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2201))
  * The combat tracker continues to work after an actor is removed from combat and the page is reloaded ([#1602](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1602))
  * The character sheet sizes its body to the header it actually has, so the skill list on the Characteristics tab no longer ends below the bottom of the window ([#1737](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1737))
  * Talent cards now include short and long descriptions when sent to chat ([#2231](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2231))
  * Dropping a talent onto a specialization no longer edits the talent that was dragged in, and dropping the same talent again replaces the node instead of stacking another copy of its modifiers onto it ([#2263](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2263))
  * Drops onto species, specialization, and career sheets now land on the sheet they were dropped on, instead of doing nothing (or landing on another sheet) when more than one sheet of that type is open ([#1708](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1708))
  * Right-click menus on the actor sheet (skills, items, talents) are drawn over the sheet rather than inside the list they belong to, so the ones near the bottom are no longer cut off unless the sheet happens to sit at the bottom of the canvas ([#1738](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1738))
  * Buying a Signature Ability on a character with no career now explains that a career is required, instead of failing silently with a console error ([#1835](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1835))
  * Item sheets opened from a compendium now stay closed, instead of reappearing a moment later once the save behind them finishes ([#1739](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1739))
  * A target's defense now adds setback dice on the alternate skill lists (Genesys, Android, Terrinoth, and Crucible), instead of only on the Star Wars one ([#1770](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1770))
  * Attachments and mods which grant hardpoints now raise the available hardpoints on the weapon or armor they are installed on, instead of being ignored ([#1970](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1970))
  * Hidden tooltips no longer swallow clicks, so the edit button on a combined Force Power or Signature Ability box can be used without splitting the boxes first ([#2075](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2075))
  * The "Base Ability" label on the Signature Ability sheet header now ends before the buttons in that corner, instead of running underneath them ([#2137](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2137))
  * Ship weapons can be dragged from one vehicle to another, and weapons, armor, gear, and ship weapons dragged off an actor sheet can now be dropped onto folders and compendiums as well ([#2257](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2257))
  * Modifiers installed on armor or weapons now reach the character carrying them, instead of going inert the moment the item is equipped ([#2281](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2281))
  * The built-in Pilot crew role picks its piloting skill from the skills in the active skill theme, so it keeps working on custom themes instead of showing "(broken role)" ([#2282](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2282))
  * Every modifier that increases a weapon's range now counts ([#2290](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2290))
  * Qualities granted by more than one attachment now add up their ranks ([#2291](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2291))
  * A quality that raises armor's soak now shows up in the soak on the armor's own sheet, not just on the character ([#2292](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2292))
  * A Modification installed in an attachment now counts toward the values the item itself shows ([#2293](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2293))
  * Opening a Modification held by one attachment now edits that attachment's copy ([#2294](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2294))
  * A talent dragged onto a species grants its modifiers once, instead of applying them a second time alongside the copy of the talent the species hands the character ([#2295](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2295))
  * Fixed an issue where combat claims were silently dropped ([#2300](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2300))
  * "Roll NPCs" in the combat tracker now picks its combatants by actor type (minion, rival, and nemesis), instead of by whether a player owns them ([#2301](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2301))
  * Rolling initiative for a vehicle with no pilot now explains that a crew member must hold the Pilot role ([#2302](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2302))
  * A side with a defeated combatant now has its spare initiative slot marked unused, so it can no longer be claimed ([#2303](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2303))
  * Removing a combatant with "Remove Last Slot" now carries a claim on that side's last slot onto the slot that replaces it, and leaves the encounter in the round it was in, instead of dropping the claim ([#2304](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2304))
  * Closing an actor sheet while edit mode is on now turns the mode off instead of leaving it on until the world is reloaded ([#2307](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2307))
  * Closing the editor for a Modification held by an attachment now simply closes it ([#2308](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2308))
  * Weapon and armor qualities which grant more than one thing (such as Defence, which covers both melee and ranged) now keep all of them when the item is saved or equipped, instead of quietly losing everything but the first ([#2311](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2311))
  * Imported items now carry one inherent Active Effect holding the values the data gave them, instead of a second copy of it alongside with every change left at zero; an imported vehicle attachment also costs the hardpoints its data names, rather than none ([#2312](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2312))
  * A weapon carrying an attachment with a Modification that has no mods on it can be rolled again, instead of the dice pool failing to open ([#2313](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2313))
  * A quality with more than one rank on a weapon or armor now gives the character every rank of it ([#2340](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2340))
  * Invalid JSON in the Custom Status Effects setting now only skips those statuses and warns once the world is up ([#2309](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2309))
  * A combatant added to an encounter already under way can roll initiative from its slot again ([#2335](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2335))
  * The system has been moved to [Data Models](https://foundryvtt.com/article/system-data-models/) ([#2053](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2053))
  * AEs from weapons and armor should now sync properly on first use ([#2363](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2363))
  * A modifier added directly to a weapon or armor now shows in the values on its own sheet ([#2360](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2360))

`2.0.3`
* Enhancements:
  * Strain, Hull Trauma, and System Strain can now be set above the threshold on tokens ([#2177](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2177))
* Fixes:
  * Fixes an issue where edit mode can get stuck on and require a reload to fix ([#2202](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2202))
  * "Rival" and "Nemesis" default images are now swapped (to their appropriate setting!)
  * The PC Wizard no longer spams a trillion temporary actors ([#2183](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2183))
  * The PC Wizard now properly sets starting/total XP and generates entries in the XP log ([#2178](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2178))
  * Fix for Talents granting their modifier when dropped onto a Specialization regardless of learned status ([#2203](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2203))
  * Encumbrance threshold now updates when manual edits to Brawn are applied ([#2197](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2197))
  * Re-importing data without also loading skills no longer automatically fails ([#2196](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2196))
  * Vehicle and Force Power sheet content heights have been corrected - they now use all available space instead of including a large amount of deadspace at the bottom ([#2194](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2194))
  * Character sheets have had their main details block slightly rearranged and had the styling slightly improved ([#2187](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2187))
  * Characteristic mods are now properly created when importing items (requires a re-import to apply) ([#2193](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2193))
  * Characteristic-based weapons now get their base damage correct without having to open/close the item sheet ([#2180](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2180))
  * Fix for Armor Soak mods not applying correctly (note that the mods will need to be re-created for the fix to apply) ([#2191](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2191))
  * Fix for weapons not receiving dice modifiers from Modifiers installed on Attachments ([#2179](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2179))
  * Hide tabs on sheets when a player has a limited view to it ([#2161](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2161))
  * The edit button is no longer shown for talents from specializations (which cannot be edited) ([#2143](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2143))
  * Correct opening Talent information for custom Specializations ([#2144](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2144))
  * Update Mod value for Career Skills to be a checkbox ([#2146](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2146))
  * Obligation/Motiviation headers are no longer smushed ([#2192](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2192))
  * Unscoped CSS in the system is now properly scoped to only impact system assets ([#2190](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2190))

`2.0.2`
* Fixes:
  * the PC wizard now works for non-GMs ([#2165](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2165))

`2.0.1`
* Fixes:
  * Correct armor and weapon encumbrance not applying to actors ([#2159](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2159))

`2.0.0`
* Enhancements:
  * Foundry v13 support!
  * Suppressing AE popups from items equipping
  * Weapons now have an ammo option, fantastic for Grenades and Launchers! ([#1984](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1984))
  * Specializations can now be set as universal via their sheets ([#2028](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2028))
  * Item sources can now be added and removed ([#2028](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2028))
  * Item and actor tags can now be viewed, added, and removed ([#2028](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2028))
    * These tags can be used by macros and will be used by the Enhancements module
  * Expanding talents on actor sheets or sending to chat now displays the long description instead of the short ([#2029](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2029))
  * Added "Active Effects" tab to character sheet ([#2060](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2060))
  * Added the ability to export/import XP log ([#2050](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2050))
  * Allow gear to have modifiers which impact actors ([#2058](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2058))
  * Allow setting images for Force Powers and Signature Abilities ([#2076](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2076))
  * Added a player character creation wizard ([#1974](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1974))
  * Added two tours to explain the system - one for basic sheet use and one for Edit Mode ([#1987](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1987))
  * Specialization, force power, and signature ability pages update the color of connections from learned talents/upgrades ([#2064](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2064))
  * Medical item flag, which allows to do less actions in order to use stimpack/droid patch: increases stimpacks usage, decreases the current healing item's quantity, applies proper amount of healing to actor's current wounds) ([#2113](https://github.com/StarWarsFoundryVTT/StarWarsFFG/pull/2113))
* Notes:
  * The OggDude _Character_ Importer has been retired ([#1988](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1988))
    * The _Data_ importer is still supported and is still recommended to import things like species, specializations, and items
* Fixes:
  * Fix armor adjusted values was not considering all modifiers for soak, defence, and encumbrance ([#1991](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1991)
  * Fix species talents/abilities being added/removed by each player online leading to duplicates if GM is online. ([#1832](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1832))
  * Fix for defence not applied during combat checks as setback dice ([#2009](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2009)()
  * Fix for defence mods to distinguish between melee and ranged ([#1985](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1985))
  * Fix uncontrolled active effect messing with actor stats while in Edit Mode - disable any change instead of the base stats ([#1976](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1976))
  * Fix for handling wasn't affecting piloting pool ([#1983](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1983))
  * Fix defence and soak is not applying from armour if created within actor sheet ([#2011](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2011))
  * Fix characteristics not applying damage to item
  * Bump dice simulation library version to bring in a fix where two dice faces were wrong
  * Mods and Modifiers can now target custom skills on actors ([#1973](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1973))
  * Imported species now correctly set Encumbrance without having to open/close them ([#1982](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1982))
  * Fix for inability to add a modifier to a talent after creating it, closing the sheet, and re-opening it ([#1972](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1972))
  * Fix vehicle sheets not opening if skill is missing from assigned crew ([#1978](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1978))
  * Max characteristic setting is now properly enforced when manually editing sheets ([#1994](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1994))
  * Purchasing a talent in a specialization now properly activates any modifiers for tha talent
  * Manually adjusting XP can be submitted with the enter key ([#2036](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2036))
  * Fix for AEs on items dragged onto actors being active despite the item not being equipped ([#2037](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2037))
  * Fix for editing specialization top description not showing current text ([#2041](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2041))
  * the OggDude Dataset importer now uses custom default images if images are not provided ([#2044](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2044))
  * Removed the `Stat All` modifier option, which was a union of `Stat`, `Weapon Stat`, `Vehicle Stat`, and `Amor Stat` ([#1986](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1986))
  * Fix universal specializations costing more XP when purchased via drag-and-drop ([#2057](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2057))
  * Moving items from a token to an actor will no longer remove the item from the parent actor of the token ([#2067](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2067))
  * Fix for Force Power upgrades sometimes being purchasable despite not having enough XP ([#2074](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2074))
  * XP granted by species is now removed if the species is removed ([#2083](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2083))
  * Fix various stats on an actor changing when Edit Mode is enabled and >1 person has the sheet open
  * Removing a species now removes associated Abilities
  * Drag-and-dropping a talent onto an actor in Genesys now prompts to spend XP
  * Macros coming from Compendiums will no longer generate an error and fail to copy
  * Drag-and-dropping items from an actor sheet now preserves Foundry-native information ([#2117](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2117))
  * Qualities on attachments are now properly transferred to items when the attachment is drag-and-dropped to an item ([#2125](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/2125))
  * Popped-out elements are no longer set to max height ([#1714](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1714))

`1.910`
* Fixes:
  * Correct XP manual adjustment bug ([#1948](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1948))
  * The chat Dice Roller now works again ([#1951](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1951))
  * Remove sheet v1 for Actors and items, as it's not being supported and can actively that actor/item ([#1950](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1950))
  * The importer now correctly processes Die modifiers, fixing talents (especially on species) ([#1957](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1957))
    * Note that this requires a re-import of the species and talents
  * Imported Species now apply characteristics to Wounds and Strain thresholds without having to open + close them once ([#1955](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1955))
    * Note that this requires a re-import of the species
  * Vehicle sheets no longer break when a crew member has been deleted ([#1959](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1959))
  * Force Dice Boost now accounts for the full Force Rating ([#1949](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1949))
  * OggDude data imports now default to deleting existing compendiums (most updated import logic relies on the compendiums not existing) ([#1964](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1964))
  * Actor sheets should no longer go wild when manually adjusting XP ([#1954](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1954))
  * Fixed a strange bug where XP would sometimes plummet to -20 and total would become null
  * Custom statuses are no longer defined in the _drawbar function (whoops lol)

`1.909`
* Features:
  * New default images have been added for common items and actors!
    * These images have been commissioned specifically for this system
    * Please check out the artists work if you like the icons! `DistraKit` [on Twitter](https://x.com/DistraKit)
  * Stamina bars now indicate when a threshold has been exceeded! ([#1912](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1912))
  * Force Dice can now be added to the Initiative roller ([#1915](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1915))
  * The Dice Pool window now shows likelihood of success for the roll (this is configurable and defaults to only GMs)
  * You can now define additional status effects to apply via the settings menu ([#1941](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1941))
* Fixes:
  * Vehicle stats can now be edited when edit mode is enabled ([#1896](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1896))
  * Removed the Active Effect from XP Adjustments to make them the same as XP Grants ([#1909](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1909))
  * Encumbrance is now properly calculated as Brawn + 5 ([#1921](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1921))
  * Career Skills from imported Careers and Specializations applies without having to open/close item once ([#1903](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1903))
  * Buying a rank in Brawn now properly increases Soak as well ([#1905](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1905))
  * Adding a Mod to an attachment on a Weapon no longer duplicates the mod ([#1838](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1838))
  * Custom skills can now be set as Career Skills by Careers / Specializations ([#1907](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1907))
  * `Skill Force Dice` modifiers now dynamically read the Force Dice pool (they still accept a number, it's just ignored ([#1890](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1890))
  * GMs granting XP no longer sends available XP plummeting like the younglings who trusted Anakin ([#1899](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1899))
  * Fix for dragging talent onto Specialization not properly persisting the Ranked property ([#1938](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1938))
  * Further improved migration of worlds made before 1.907

`1.908`
* Fixes:
  * Correct several bugs in the world migration code for `1.907`

`1.907`
* Features:
  *  [Active Effects](https://foundryvtt.com/article/active-effects/) have been implemented. This means it's now possible to make changes to actors with status effects - [even custom ones](https://github.com/StarWarsFoundryVTT/StarWarsFFG/wiki/Creating-New-Statuses)!
  * New built-in status effects for single-use boost/setback dice, staggered, disoriented, and staggered
  * End-to-end tests for new functionality are in place. Hopefully, this will reduce bugs going forward ([#1837](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1837))
  * Add Force Power Roll button ([#1827](http://overlord.wrycu.com:12121/game))
  * Added support for universal specializations (requires a re-import of the data) ([#1778](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1778))
  * Noted that Oggdude _character_ importer is deprecated and is likely to result in stat mismatches
  * Career skills now have first-class support and can be set without using modifiers! ([#1861](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1861))
  * some XP purchases made going forward can be refunded ([#1809](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1809))
* Fixes:
  * Talent modifiers on specializations are now properly cleaned up when a new talent overrides an old one
  * Force powers, signature abilities, and specializations now use a unified UI to editing upgrades/talents on their sheets ([#1828](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1828))
  * Dragging a talent onto a specialization now properly copies the state of forceTalent, conflictTalent, and Ranks ([#1805](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1805))
  * Modifier options are now unified: the same options are presented, regardless of actor, mod, or attachment type ([#1800](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1800))
  * Vehicle images are now properly capped at 200 px high ([#1807](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1807))
  * The custom combat tracker now supports using the `secret` token disposition ([#1813](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1813))
  * It's now possible to remove an actor from the custom combat tracker even if no slots have been claimed this round
  * Corrected translations not occurring for Initiative mode and group manager PC list mode ([#1814](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1814))
  * Corrected default item names when created in actors ([#1815](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1815))
  * The crew role update button is now localized ([#1822](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1822))
  * The Popout modifier window now has a scrollbar! You can now see the giant modifier list directly on force powers ([#1824](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1824))
  * Fix for talent send-to-chat not working if the talent came from a specialization ([#1819](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1819))
  * Update "Not enough XP" language to be more generic ([#1820](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1820))
  * A limited subset of qualities now have dice mods created upon import ([#1836](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1836))
  * Actors who roll a `0` for initiative no longer continue to show a prompt to roll initiative ([#1865](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1865))
  * Fix for removing actor before combat starts - the slot is no longer retained as a generic slot and is deleted ([#1864](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1864))
  * Prevent duplicate Hook activation on Actor sheets ([#1818](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1818))

`1.906`
* Features:
  * Compendiums have been migrated back to world compendiums (from system compendiums) ([#1794](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1794))
    * This means they will not be deleted every update _after this one_
    * Once again: **THIS UPDATE WILL DELETE ALL SYSTEM COMPENDIUMS**
  * Attachments now actually work! ([#1215](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1215), [#1768](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1768))
  * Item qualities, upgrades, etc now use tooltips instead of a fake item window when sent to chat
  * You can now adjust token wounds above the threshold ([#1769](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1769))
  * Token bars now display wounds above threshold and most colors are configurable ([#1769](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1769))
  * You can now kill a minion or minion group directly from their sheet with a single click! ([#1744](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1744))
  * Add derived stats of strainOverThreshold, woundsOverThreshold, hullOverThreshold, and systemStrainOverThreshold to actors (for things like Bar Brawl) ([#1781](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1781))
  * You can now provide a reason for manual XP adjustments ([#1630](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1630))
  * Users with limited view access on Nemesis actors can now view the bio. (GMs can hide content by using the `secret` block in the Bio) ([#1774](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1774))
* Fixes:
  * Remove usage of deprecated `math.clamped` in favor of `math.clamp`
  * Fix skill roll sometimes showing a pool of only 2 difficulty when clicked ([#1763](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1763))
  * XP Spending now uses a generic symbol instead of a dollar sign ([#1732](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1732))
  * Fix for skill-roll macros not being created on drag-and-drop into macro hotbar ([#1786](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1786))
  * Prevent abilities on species from duplicating when the importer is run more than once ([#1721](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1721))
  * Do not import item name in the description of the item ([#1795](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1795))
  * Do not include base mods in weapon description when running the importer ([#1795](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1795))
  * Unranked unique mods are now properly imported without ranks ([#1795](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1795))
  * Correct talent ownership bug ([#1773](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1773))
  * Show error if a non-custom skill is removed from actor ([#1571](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1571))
  * Update wording of `Dice Theme` setting to more accurately reflect what it changes ([#1795](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1795))

`1.905`
* Fixes
  * Hotfix for inability to roll dice with modifiers (e.g. critical injuries)

`1.904`
* Features:
  * Optionally include GM Characters in the Group Manager ([#1680](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1680))
  * Add EditorConfig settings
  * Add basic Eslint config
  * Alphabetize species, careers, specializations, signature abilities, and force powers on actor sheets ([#1723](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1723))
  * A notification will be generated if all system compendiums are empty ([#1693](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1693))
  * The importer now has a "select all" so you don't have to click each item individually ([#1724](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1724))
  * Add long description for talents and move sources out of description for all items ([#1640](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1640))
  * Weapon "special" field moved to the configuration tab ([#1715](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1715))
* Fixes:
  * Apply Force Powers upgrades to character ([#1542](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1542))
  * Imported skill modifiers have better formatted attributes key names ([#1663](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1663))
  * Updated Spanish localizations
  * Updated French localizations
  * Retain token settings when copying actors ([#1673](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1673))
  * Non FFG Dice rolls with multiple terms are accepted again ([#1664](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1664))
  * Escape menu toggles in the normal way again ([#1670](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1670))
  * Force Power: Empty mod list doesn't reset basic force power anymore ([#1669](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1669))
  * Updating a talent from a specialization tree updates the tree ([#1643](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1643))
  * Force Power: Import basic force power mods ([#1686](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1686))
  * Get embedded item data from `system` variable instead of root
  * Use correct type when importing a Force Boost mods ([#1687](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1687))
  * Item attachments' mods use parent item mod type when present ([#1624](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1624))
  * Talent cost set when preparing tree instead of template ([#1704](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1704))
  * Qualities are linked to parent item ([#1612](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1612))
  * Assign correct modifiers type to armor: "armour" instead of "armor" ([#1697](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1697))
  * Remove Destiny Tracker hardcoded size, allowing it to grow and shrink when font size is changed ([#1688](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1688))
  * Assign correct modifiers type to armor: "armour" instead of "armor" ([#1697](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1697))
  * Skill purchases on actors now work via the dollar sign again ([#1713](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1713))
  * Use defense when building pool bug ([#1603](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1603))
  * Allow to set challenge dices when create a dice pool.
  * Allow zero as a valid value when updating vehicle stats ([#1717](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1717))
  * Replace deprecated Document.createDocuments calls with Document() constructor ([#1683](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1683))
  * Problem with Destiny Roll ([#1730](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1730))
  * Show removed setback dice icons and optionnally remove them from all rolls ([#1720](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1720))
  * Problem with rolling of standard dice ([#1731](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1731))
  * Allow weapon status check for dice roll also for shipweapon
  * Blind GM rolls are now properly hidden from players ([#1712](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1712))
  * Properly use Genesys story points when the theme is set to Genesys ([#1711](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1711))
  * Stop using deprecated `select` Handlebars helper ([#1632](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1632))
    * Note that the same _code_ is in use, it is just no longer using the built-in (and deprecated) version
  * Correctly show claimed slot combatants in combat tracker ([#1703](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1703))
  * Combat tracker no longer spawns infinite combatants under certain conditions ([#1733](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1733))

`1.903`
* Features:
  * Updated "item cards" to match the Mandar theme
    * This change includes many minor improvements to the cards, such as showing damage on weapons and purchased talents on specializations
  * Generic slot combat tracker: The action to take when removing a combatant is now configurable. This is in place of the previously-confusing (and quite annoying) behavior where you had to claim a slot in order to remove a combatant
  * Dragging-and-dropping items on actors now prompts for spending XP to purchase that item ([#1588](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1588))
  * XP spending now consistently uses a dollar sign to trigger spending instead of the various methods it previously used ([#1629](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1629))
  * Settings have been refactored to be more organized and easier to navigate ([#1639](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1639))
  * Destiny point flipping is now themed ([#1658](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1658)
  * Set default token settings when creating new actor ([#1652](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1652)))
* Fixes:
  * Includes species characteristics bonus when calculating characteristic upgrade cost ([#1638](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1638))
  * Specializations: Talents are now correctly looked up in compendium ([#1642](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1642)))
  * Generic slot combat tracker: Removed "unused" slot checking (on combatant defeat) as they would sometimes lead to actors being unable to act
  * Weapon `special` text now properly renders dice icons ([#1625](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1625))
  * Species without ability don't cause an error preventing their talents from being loaded anymor ([1641](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1641)))
  * Specializations: Embedded talents are now correctly linked to their compendium ([#1650](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1650)))
  * Vehicle `Pilot` role now works for Genesys ([#1597](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1597))

`1.902`
* Features:
  * Modified the Specialization sheet; moved the XP cost off of the talents, changed the appearance of talent connections, and improved how the sheet scales when the window is resized.
  * Increased the default size of the popout editor (e.g., used for editing the description of a Specialization)
  * Purchase improvements
    * Grouped specializations in selection popup by in and out of career
    * Grouped force powers in selection popup  by required force rating
    * Spending XP now whispers the GM to notify them (this can be disabled in the system settings)
  * Manual XP adjustments now result in an entry in the XP log
  * Max characteristic and skill ranks are now configurable ([#1532](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1532))
* Fixes:
  * Removed the "purchase" context menu option when editing a Specialization that is not attached to a character
  * Improves nested tag formatting (e.g., allows for strings like `[B]Average ([di][di]) Skill[b]` to properly render)
  * Purchasing force powers now looks at the correct attribute (it should no longer claim you are not strong enough in the force for powers!) ([#1584](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1584))
  * Vehicle weapon images now have a max width of 500px (up from 130px) ([#1576](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1576))
  * Fixed talent descriptions not showing up on specializations after being dragged-and-dropped ([#1573](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1573))
  * Fixed destiny pool roll not populating in tracker ([#1592](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1592))
  * Specializations no longer take forever to open ([#1593](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1593))
  * SWA import now properly imports ranked talents ([#1572](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1572))
  * SWA import no longer improperly matches the wrong talents in rare occasions
  * Characteristic XP cost is now calculated excluding any boosts from modifiers ([#1594](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1594))

`1.901`
* Features:
  * Added a sheet option to disable Force Pool on Rival and Nemesis actor sheets ([#1502](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1502))
  * The importer will no longer include every source as a header element, making it easier to read
* Fixes:
  * Fixed a bug where item qualities sometimes showed "you do not have permission to view this item" for non-GMs ([#1552](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1552))
  * Fixed changing skill characteristics not working ([#1550](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1550))
  * Skill descriptions are now properly imported ([#1551](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1551))
  * Talents from species no longer multiply ranks when combined with purchased talents ([#1540](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1540))
  * Fixed a bug where some text disappeared from descriptions ([#1559](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1559))
  * Fixed a bug where paragraph tags did not properly result in new lines
  * Creating combat via the group manager now works again ([#1545](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1545))
  * Removing initiative slots from combat now works ([#1545](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1545))
  * Soak can now go below the Brawn value if auto-calculation is turned off ([#1371](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1371))
  * Imported Vehicle improvements ([#1537](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1537)):
    * Navicomputer is now imported
    * Hyperdrive primary is set to null if no hyperdrive is installed
    * Hyperdrive secondary is imported (and set to null if no hyperdrive is installed)
  * `system.json` no longer generates warnings ([#1538](https://github.com/StarWarsFoundryVTT/StarWarsFFG/issues/1538))
  * Weapon-on-actor macros now work with the Enhancements module animations ([enhancements module #202](https://github.com/wrycu/StarWarsFFG-Enhancements/issues/202))

`1.900`
* Features:
  * Support for FoundryVTT v12
    * Compendiums are now system defined. This means they cannot be deleted, but was required for the v12 migration
  * **Characters / Nemesis / Rivals / Minions**
    * All actor sheets now default to v2 (they can still be manually changed back to v1)
    * v2 sheets: Critical injuries are now in a dedicated tab
    * Characters: Players can now buy levels in characteristics by clicking the characteristic name
    * Characters: XP available/total moved to XP log tab
    * Characters with v2 sheets: Obligation / morality / conflict moved to a dedicated tab
    * Nemesis / Rivals / Minions: Abilities created during the SWA import process are now created as "Ability" items instead of populating in the biography section
  * **Vehicles**
    * Overall tab layout updated
    * Vehicles can now be classified as "space" or "not space"
      * This data is automatically included when the importer is run
    * A single, dedicated "pilot" role was created which selects the appropriate skill based on how the vehicle is classified ("space" or "not space")
    * You can now roll a vehicle weapon using a crew member from that weapon
    * Crew selection is now a multi-select dropdown instead of requiring you to drag-and-drop the same actor multiple times
    * Dragging crew onto vehicles now prompts for the initial role selection, instead of assigning "(none)"
    * Defense silhouettes are now customizable
      * This data is automatically included when the importer is run
  * **Items**
    * All item sheets now default to v2 (they can still be manually changed back to v1)
    * Signature abilities can now have required specialization upgrades defined
      * This data is automatically included when the importer is run
      * If defined on a signature ability, attempting to purchasing it checks if the required specialization upgrades are purchased
    * Purchasing Force Powers now checks the required force rating
    * Species can now have starting XP defined
      * This data is automatically included when the importer is run
      * Dragging a species onto a player character grants the starting XP
    * Species can now include abilities to grant the actor they are added to
      * This data is automatically included when the importer is run
    * Obligations and duties may now have notes set on them
      * This data is automatically included when the character importer is run
  * **Combat**
    * The target's defense dice are now added if you target it (this is configurable per-client)
  * **Importer-specific changes**
    * The importer now includes categories from the source dataset intended for programmatic interpretation, e.g. the Holdout Blaster is tagged with "Blaster Pistol", "Holdout blaster", "Blaster", "Pistol", "Ranged"
* Fixes:
  * **Characters / Nemesis / Rivals / Minions**
    * Corrected tooltip for equipped/unequipped gear (and localized it)
    * Fixed a bug where talents displayed blank
    * Fixed a bug where attempting to view a talent on a specialization tree did not open anything
    * Swapped "melee" and "ranged" defense to match the printed books
    * Nemesis / Rivals / Minions: Removed ability to buy skill ranks
    * Characters: Added a check for sufficient XP for purchasing Signature Abilities and Force powers
    * Characters: The buy talent button on specializations no longer disappears when buying >1 talent at a time
    * Characters: "Fix" purchasing skills at the bottom of the skill list by adding a dedicated purchase button
    * Characters: The XP log no longer shows an edit button, as it is currently read only
    * Characters: Fixed a bug where talents directly granted to an actor (i.e. not via a specialization) did not appear on the first opening of the character sheet each load
    * Minions: Show "group skill" instead of "career skill"
  * **Vehicles**
    * Vehicle mods are now imported as the correct type (ship mods)
  * **Items**
    * Sending a signature ability to chat now includes purchased upgrades
    * Fix overflowing "special" field on weapons in Mandar theme
    * Correct default Signature ability height so the bottom isn't ever-so-slightly cut off
    * The "talent" tab on species items now uses the talent icon instead of the configure icon
    * The "item modifier" item type has had the description height corrected
  * **Combat**
    * Fixed double-slot-claim bug in the combat tracker
    * Fixed a bug preventing removing combatants from combat
    * Fixed a bug  where removing a combatant would un-claim another slot
    * Fixed a bug where removing a combatant from the canvas would not properly update the tracker
  * **Importer**:
    * Career data (signature abilities, specializations) is now properly set when the OggDude importer is run with existing compendiums
    * Re-running the importer no longer duplicates weapons on vehicles
    * Vehicle images are now imported when "vehicles" are imported
  * **Misc**
    * Granting XP to the entire group now updates the XP logs for those players (previously, only single-actor grants updated the log)

`1.809`
* Features:
  * You can now (optionally) spend XP! See [the wiki](https://github.com/StarWarsFoundryVTT/StarWarsFFG/wiki/new%E2%80%90features%E2%80%90v1.809#xp-spending) for more info
  * Added actor types for Nemesis and Rival
  * Weapons can now have stat mods (permitting setting e.g. the `defensive` quality)
  * Initiative rolls can be upgraded
  * Actor dice pools now show fixed results
  * `Remove setback dice` is now shown on crew dice pools
  * Wounds and stats are set as the default stats for tokens
  * Gear, weapons, and armor can now hide the `price` and `rarity` fields (via sheet options)
  * Macros are now created with the image of the item and can be created to display items
  * Specializations and signature abilities can be associated with careers (see "new importer features" below)
  * Signature abilities now have a base cost (see "new importer features" below)
  * Species can now include talents (see "new importer features" below)
  * New importer features:
    * Species talents are now set
    * Career specializations and signature abilities are now imported
    * Signature ability base cost is imported
    * Force power base cost and minimum force rating is imported
    * SWA importer imports actors as Nemesis/Rival/Minion as appropriate
* Fixes:
  * Corrected dice images for Genesys not properly embedded in Journals
  * CSS:
    * Reworked scroll heights for most sheets
    * Reworked name centering for most sheets
    * Fixed giant dice in expanded roll card in the Mandar theme. Again.
  * Importer improvements:
    * Ship attachments are now set to the correct item type
    * Misc qualities on weapons/armor are now imported properly
  * Improved GM detection for combat events
  * Fixed expanding items with `null` item qualities (e.g. expanding a weapon on an actor sheet)
  * Fixed viewing item qualities with HTML elements in them
  * Fix for non-GMs being unable to open some item qualities
  * Fix for drag-and-drop items from compendiums not working until the item sheet was opened at least once
  * Fixed a bug for adversary levels above 5 not showing up
